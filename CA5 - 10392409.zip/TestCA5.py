# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 22:26:34 2018

@author: admin
"""

import unittest
from CA5 import add, multiply, subtract, divide, cube, squareRoot, factorial, sin, square, cos

class CalculatorTest(unittest.TestCase):
    
    def testAdd(self):
        self.assertEqual(6, add([1,2,3]))
        self.assertEqual(8, add([2,2,4]))
        self.assertEqual(20, add([5,6,9]))
        self.assertEqual(8, add([-2,5,5]))
        
    def testMultiply(self):
        self.assertEqual(36, multiply([2,2,9]))
        self.assertEqual(80, multiply([5,2,8]))
        self.assertEqual(95, multiply([-5,-1,19]))
        self.assertEqual(180, multiply([2,-6, -15]))
       
    def testSubtract(self):
        self.assertEqual(-6, subtract([5,3,8]))
        self.assertEqual(-11.5, subtract([9,8,12.5]))
        self.assertEqual(48, subtract([70,100,-78]))
        self.assertEqual(1.75, subtract([-5,-8, 1.25]))
        
    def testDivide(self):
        self.assertRaises(ZeroDivisionError, divide,([10,0,3]))
        self.assertEqual(-0.6, divide([9,-3, 5]))
        self.assertEqual(1.2, divide([90,12.5, 6]))
        self.assertRaises(ZeroDivisionError, divide, [5,0,8])
        
    def testCube(self):
        self.assertEqual([8, 64, -125], cube([2, 4, -5]))
        self.assertEqual([125, 27, 512 ], cube([5,3, 8]))
        self.assertEqual([-216, 0.5120000000000001, 512000 ], cube([-6,0.8, 80]))
       
       
    def testSquare(self):
        self.assertEqual([4, 9, 144], square([2, 3, 12]))
        self.assertEqual([625,0.25, 16], square([-25, 0.5, 4]))
        self.assertEqual([0.31360000000000005, 25, 100], square([0.56, 5, 10]))
   
    
    def testSquareRoot(self):
        self.assertEqual([4,3, 6], squareRoot([16, 9, 36]))
        self.assertEqual([2, 25, 12], squareRoot([4, 625, 144]))
        self.assertEqual([4.47213595499958, 10, 8], squareRoot([20, 100, 64]))
    
        
    def testFactorial(self):
        self.assertEqual([2, 6, 40320], factorial([2, 3, 8]))
        self.assertEqual([1, 24, 120], factorial([0, 4, 5]))
        self.assertEqual([720, 1, 5040], factorial([6, 1, 7]))
        
    
    def testSin(self):
        self.assertEqual([-0.27941549819892586,0.8414709848078965, 0.1411200080598672], sin([6, 1, 3]))
        self.assertEqual([-0.9092974268256817, 0.09983341664682815, -0.7568024953079282], sin([-2, 0.1, 4]))
        self.assertEqual([-0.5440211108893698,0.4121184852417566, 0.9893582466233818 ], sin([10, 9, 8]))
       
        
    def testCos(self):
        self.assertEqual([-0.9576594803233847, 0.022126756261955736, 0.5403023058681397], cos([16, 55, 1]))
        self.assertEqual([-0.32328956686350335, 0.955336489125606, -0.9111302618846769], cos([1.9, 0.3, 9]))
        self.assertEqual([-0.8578030932449878, -0.9111302618846769, -0.4480736161291701], cos([-78, -9, 90]))
       
    
   
    
if __name__ == '__main__':
    unittest.main()
