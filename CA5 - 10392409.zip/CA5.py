# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 22:30:32 2018

@author: admin
"""
# CA5 Calculator with lambda, reduce, map and list comprehension
from functools import reduce
import math
import numpy


def add(list_user):
    return reduce((lambda x,y: x+y), list_user)


#Multiply
def multiply(list_user):
    return reduce((lambda x,y: x*y), list_user)


#Subtract:
def  subtract (list_user):
    return reduce((lambda x,y: x-y), list_user)

#Divide
def  divide(list_user):
    if all(lambda y: y != 0 for y in list_user):
       return reduce((lambda x,y: x/y), list_user) 
    else:
       return 'division by zero!'
   
#Square
def square(list_user):
    return [ x**2 for x in list_user]


#Exponent = cube
def cube(list_user):
    return [ x**3 for x in list_user]
    

#squareRoot
def squareRoot(list_user):
       return list(map(lambda x: math.sqrt(x), list_user))
   
#Factorial 
def factorial(list_user):
   return list(map(lambda x: math.factorial(x), list_user))
   
   
#sine
def sin(list_user):
    return list(map(lambda x: math.sin(x), list_user))


#cosine
def cos(list_user):
    return list(map(lambda x: math.cos(x), list_user))